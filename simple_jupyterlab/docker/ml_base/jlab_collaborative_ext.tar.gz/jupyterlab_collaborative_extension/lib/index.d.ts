import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
